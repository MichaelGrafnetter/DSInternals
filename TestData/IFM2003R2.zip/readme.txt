These files come from a System State backup created on a Windows Server 2003 R2 DC with Windows 2000 Mixed DFL.

Trying to open this DB threw an exception. This command has fixed it:
esentutl /p ntds.dit

In a future version, we will try to detect this state and call the JetRestore function automatically.
https://msdn.microsoft.com/en-us/library/gg294093%28v=exchg.10%29.aspx