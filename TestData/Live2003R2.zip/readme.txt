These files come from a live Windows Server 2003 R2 DC with Windows 2000 Mixed DFL.

SysKey: a6ea2b82b3dfb0afd133d0b59cd05f8e